# date/time scales raise error on incorrect inputs

    `transform_time()` works with objects of class <POSIXct> only

---

    `transform_date()` works with objects of class <Date> only

