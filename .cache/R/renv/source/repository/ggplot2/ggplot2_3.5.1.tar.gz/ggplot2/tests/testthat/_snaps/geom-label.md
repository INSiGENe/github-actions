# geom_label() throws meaningful errors

    Both `position` and `nudge_x`/`nudge_y` are supplied.
    i Choose one approach to alter the position.

---

    `label` must be of length 1.

