# geom_map() checks its input

    `map` must be a data frame, not a character vector.

---

    `map` must have the columns `x`, `y`, and `id`.

