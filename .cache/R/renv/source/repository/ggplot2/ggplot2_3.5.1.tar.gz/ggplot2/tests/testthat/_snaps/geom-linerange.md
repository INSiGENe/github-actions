# geom_linerange request the right aesthetics

    Problem while setting up geom.
    i Error occurred in the 1st layer.
    Caused by error in `compute_geom_1()`:
    ! `geom_linerange()` requires the following missing aesthetics: ymax or xmin and xmax.

