# calc_bw() requires at least two values and correct method

    `x` must contain at least 2 elements to select a bandwidth automatically.

---

    `test` is not a valid bandwidth rule.

