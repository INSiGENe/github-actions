# error is thrown with wrong quantile input

    Computation failed in `stat_qq()`.
    Caused by error in `compute_group()`:
    ! The length of `quantiles` must match the length of the data.

---

    Computation failed in `stat_qq_line()`.
    Caused by error in `compute_group()`:
    ! `quantiles` must have the same length as the data.

---

    Computation failed in `stat_qq_line()`.
    Caused by error in `compute_group()`:
    ! Cannot fit line quantiles 0.15. `line.p` must have length 2.

