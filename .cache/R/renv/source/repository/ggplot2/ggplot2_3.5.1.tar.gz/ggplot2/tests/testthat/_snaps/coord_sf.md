# axis labels can be set manually

    `breaks` and `labels` along `x` direction have different lengths.

---

    `breaks` and `labels` along `y` direction have different lengths.

---

    Graticule labeling format not recognized.

---

    Panel labeling format not recognized.

# default crs works

    Scale limits cannot be mapped onto spatial coordinates in `coord_sf()`.
    i Consider setting `lims_method = "geometry_bbox"` or `default_crs = NULL`.

# coord_sf() throws error when limits are badly specified

    `xlim` must be a vector of length 2, not a <ScaleContinuousPosition/ScaleContinuous/Scale/ggproto/gg> object.

---

    `ylim` must be a vector of length 2, not an integer vector of length 3.

