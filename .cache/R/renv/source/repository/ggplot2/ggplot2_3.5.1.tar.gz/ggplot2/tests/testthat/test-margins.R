test_that("justify_grobs() checks input", {
  expect_snapshot_error(justify_grobs(1))
})
