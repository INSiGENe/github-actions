# limits() throw meaningful errors

    All arguments must be named.

---

    `linewidth` must be a two-element vector.

